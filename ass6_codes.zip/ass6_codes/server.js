const express = require('express');
const mongoose = require('mongoose');
const bookRoutes = require('./routes/bookRoutes');  // Import the book routes

const app = express();
const PORT = 3000;

app.use(express.json()); // Middleware to parse incoming JSON requests

// Database connection
mongoose.connect('mongodb://localhost:27017/booksdb', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log('Connected to the database');
}).catch(err => {
  console.error('Database connection error:', err);
});

// Use the book routes
app.use('/api/books', bookRoutes);  // Ensure this line exists and is correct

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
