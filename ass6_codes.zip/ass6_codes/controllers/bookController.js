const Book = require('../models/bookModel');

// Controller for adding a new book (POST)
exports.createBook = async (req, res) => {
  const { title, author, isbn, publishedDate, genre, availableCopies } = req.body;

  try {
    const newBook = new Book({
      title,
      author,
      isbn,
      publishedDate,
      genre,
      availableCopies,
    });

    await newBook.save();  // Save the book to the database
    res.status(201).json({ message: 'Book added successfully!', book: newBook });
  } catch (error) {
    res.status(500).json({ message: 'Failed to add the book', error });
  }
};

// Controller for getting all books (GET)
exports.getBooks = async (req, res) => {
  try {
    const books = await Book.find();  // Retrieve all books from the database
    res.status(200).json(books);  // Respond with the list of books
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch books', error });
  }
};

// Controller for getting a book by ID (GET)
exports.getBookById = async (req, res) => {
  const { id } = req.params;

  try {
    const book = await Book.findById(id);  // Retrieve the book by ID from the database
    if (!book) {
      return res.status(404).json({ message: 'Book not found' });
    }
    res.status(200).json(book);  // Respond with the found book
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch the book', error });
  }
};
