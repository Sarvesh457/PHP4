const express = require('express');
const router = express.Router();
const bookController = require('../controllers/bookController');

// Route for creating a new book (POST)
router.post('/', bookController.createBook);

// Route for getting all books (GET)
router.get('/', bookController.getBooks);  // New route for retrieving all books

// Route for getting a book by ID (GET)
router.get('/:id', bookController.getBookById);  // New route for retrieving a book by ID


module.exports = router;
