import React, { useState } from 'react';
import './UserForm.css';

const UserForm = () => {
  const [formData, setFormData] = useState({ name: '', email: '' });
  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    setErrors({ ...errors, [name]: '' });
  };

  const validateEmail = (email) => /\S+@\S+\.\S+/.test(email);

  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = {};
    if (!formData.name) newErrors.name = 'Name is required';
    if (!formData.email) newErrors.email = 'Email is required';
    else if (!validateEmail(formData.email)) newErrors.email = 'Invalid email format';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
    } else {
      setSuccessMessage('Form submitted successfully!');
      setFormData({ name: '', email: '' });
    }
  };

  return (
    <form className="user-form" onSubmit={handleSubmit}>
      <InputField label="Name" name="name" value={formData.name} onChange={handleChange} error={errors.name} />
      <InputField label="Email" name="email" value={formData.email} onChange={handleChange} error={errors.email} />
      <button type="submit" className="submit-button">Submit</button>
      {successMessage && <div className="success">{successMessage}</div>}
    </form>
  );
};

const InputField = ({ label, name, value, onChange, error }) => (
  <div className="input-field">
    <label>{label}</label>
    <input
      name={name}
      value={value}
      onChange={onChange}
      className={error ? 'error' : ''}
    />
    {error && <div className="error-message">{error}</div>}
  </div>
);

export default UserForm;
