import React, { useState } from 'react';
import './ResumeBuilder.css';

const ResumeBuilder = () => {
  const [resumeData, setResumeData] = useState({
    summary: '',
    education: '',
    skills: '',
    objective: '',
    experience: '',
    achievements: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setResumeData({ ...resumeData, [name]: value });
  };

  return (
    <div className="resume-builder">
      <h1>Resume Builder</h1>
      {Object.keys(resumeData).map((key) => (
        <Section
          key={key}
          label={key.charAt(0).toUpperCase() + key.slice(1)}
          name={key}
          value={resumeData[key]}
          onChange={handleChange}
        />
      ))}
      <h2>Preview:</h2>
      <div className="preview">
        {Object.entries(resumeData).map(([key, value]) => (
          <div key={key} className="preview-item">
            <strong>{key.charAt(0).toUpperCase() + key.slice(1)}:</strong> {value}
          </div>
        ))}
      </div>
    </div>
  );
};

const Section = ({ label, name, value, onChange }) => (
  <div className="section">
    <label>{label}</label>
    <textarea name={name} value={value} onChange={onChange} />
  </div>
);

export default ResumeBuilder;
