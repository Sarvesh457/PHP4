import React, { useState } from 'react';
import './Calculator.css'; // Import CSS file for styling

const Calculator = () => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');

  const handleButtonClick = (value) => {
    setInput(input + value);
  };

  const handleCalculate = () => {
    try {
      setResult(eval(input));
    } catch (error) {
      setResult('Error');
    }
  };

  const handleClear = () => {
    setInput('');
    setResult('');
  };

  return (
    <div className="calculator">
      <div className="display">
        <div className="result">{result}</div>
        <input className="input" value={input} readOnly />
      </div>
      <div className="buttons">
        {['1', '2', '3', '+', '4', '5', '6', '-', '7', '8', '9', '*', '0', '.', '=', '/'].map((value) => (
          <Button key={value} value={value} onClick={() => value === '=' ? handleCalculate() : handleButtonClick(value)} />
        ))}
        <button className="clear" onClick={handleClear}>C</button>
      </div>
    </div>
  );
};

const Button = ({ value, onClick }) => (
  <button className="button" onClick={onClick}>{value}</button>
);

export default Calculator;
