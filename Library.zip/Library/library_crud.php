<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "library";

// Create connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert a new book
if (isset($_POST['insert'])) {
    $book_name = $_POST['book_name'];
    $isbn_number = $_POST['isbn_number'];  // Ensure this matches the form field
    $author = $_POST['author'];
    $publication = $_POST['publication'];

    // Corrected query for inserting the book
    $sql = "INSERT INTO books (book_name, isbn_number, author, publication) 
            VALUES ('$book_name', '$isbn_number', '$author', '$publication')";

    if ($conn->query($sql) === TRUE) {
        echo "New book added successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Update a book's details
if (isset($_POST['update'])) {
    $isbn_number = $_POST['isbn_number'];  // Use 'isbn_number'
    $book_name = $_POST['book_name'];
    $author = $_POST['author'];
    $publication = $_POST['publication'];

    $sql = "UPDATE books SET book_name='$book_name', author='$author', publication='$publication' 
            WHERE isbn_number='$isbn_number'";

    if ($conn->query($sql) === TRUE) {
        echo "Book details updated successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Delete a book by ISBN number
if (isset($_POST['delete'])) {
    $isbn_number = $_POST['isbn_number'];  // Use 'isbn_number'

    $sql = "DELETE FROM books WHERE isbn_number='$isbn_number'";

    if ($conn->query($sql) === TRUE) {
        echo "Book record deleted successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Search for a book by ISBN number
if (isset($_POST['search'])) {
    $isbn_number = $_POST['isbn_number'];  // Use 'isbn_number'

    $sql = "SELECT * FROM books WHERE isbn_number='$isbn_number'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table border='1'>
                <tr>
                    <th>Book Name</th>
                    <th>ISBN Number</th>
                    <th>Author</th>
                    <th>Publication</th>
                </tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row['book_name'] . "</td>
                    <td>" . $row['isbn_number'] . "</td>
                    <td>" . $row['author'] . "</td>
                    <td>" . $row['publication'] . "</td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "No records found!";
    }
}

// Close the connection
$conn->close();
?>
