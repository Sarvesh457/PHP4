<?php
$conn = new mysqli("localhost", "root", "", "student");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['submit'])) {
    $first_name = $conn->real_escape_string($_POST['first_name']);
    $last_name = $conn->real_escape_string($_POST['last_name']);
    $roll_no = $conn->real_escape_string($_POST['roll_no']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Hash the password
    $contact_number = $conn->real_escape_string($_POST['contact_number']);

    $sql = "INSERT INTO user (first_name, last_name, roll_no, password, contact_number)
            VALUES ('$first_name', '$last_name', '$roll_no', '$password', '$contact_number')";

    if ($conn->query($sql) === TRUE) {
        // Redirect to the main page after successful creation
        header("Location: index.php?message=Student+registered+successfully");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
