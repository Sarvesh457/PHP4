<?php
$conn = new mysqli("localhost", "root", "", "student");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['delete'])) {
    $roll_no = $_POST['roll_no'];

    $sql = "DELETE FROM user WHERE roll_no = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $roll_no);

    if ($stmt->execute()) {
        // Redirect to the main page after successful deletion
        header("Location: index.php?message=Student+record+deleted+successfully");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
