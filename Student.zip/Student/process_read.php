<?php
$conn = new mysqli("localhost", "root", "", "student_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT first_name, last_name, roll_no, contact_number FROM students";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["first_name"] . "</td><td>" . $row["last_name"] . "</td><td>" . $row["roll_no"] . "</td><td>" . $row["contact_number"] . "</td></tr>";
    }
} else {
    echo "<tr><td colspan='4'>No records found</td></tr>";
}

$conn->close();
?>
