<?php include 'header.php'; ?>

<div class="container mt-4">
    <h2>Delete Student Record</h2>
    <form action="process_delete.php" method="post">
        <div class="mb-3">
            <label for="roll_no" class="form-label">Roll No/ID:</label>
            <input type="text" id="roll_no" name="roll_no" class="form-control" required>
        </div>
        <button type="submit" name="delete" class="btn btn-danger">Delete</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.min.js"></script>
</body>
</html>
