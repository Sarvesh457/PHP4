<?php
$conn = new mysqli("localhost", "root", "", "student");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['update'])) {
    $roll_no = $_POST['roll_no'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $password = $_POST['password'];
    $contact_number = $_POST['contact_number'];

    $sql = "UPDATE user SET first_name='$first_name', last_name='$last_name', password='$password', contact_number='$contact_number' WHERE roll_no='$roll_no'";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php?message=Student+record+updated+successfully");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
