<?php include 'header.php'; ?>
<div class="container mt-4">
    <h1>Welcome to the Student Registration System</h1>
    <p>Use the navigation menu to manage student records.</p>
</div>
<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.min.js"></script>
</body>
</html>
